# Smart Student Management System

A Java console application with a Java Swing desktop GUI. The GUI uses the existing `Student`, `StudentManager`, and grade-calculation logic.

## Features
- Add students (registration number, name, course, marks)
- View student records in a searchable table
- Search by registration number, name, or course
- Update marks and recalculate grade
- Delete records with confirmation
- Dashboard statistics: total students, average marks, pass rate, students passed
- Performance summary with top performer
- Input validation and duplicate registration-number checks

## Requirements
- Java JDK 8 or newer

## Run in VS Code
1. Open this folder in VS Code with the Java Extension Pack installed.
2. Open `src/main/StudentManagementGUI.java`.
3. Click **Run** above the `main` method.

## Run from a terminal
From the project root:

```bash
javac -d bin src/model/Student.java src/service/StudentManager.java src/main/StudentManagementGUI.java
java -cp bin main.StudentManagementGUI
```

The original console program can still be run with:

```bash
javac -d bin src/model/Student.java src/service/StudentManager.java src/main/Main.java
java -cp bin main.Main
```

## Note
This project currently stores student records in memory. Records are reset when the program closes; persistent database storage is not implemented in the original backend.
