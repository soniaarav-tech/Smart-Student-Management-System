package service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.Student;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

public class StudentManager {

    private ArrayList<Student> students = new ArrayList<>();

    // Keep the data outside the project folder so it survives closing the GUI
    // and recompiling the project. The file is created automatically.
    private static final Path DATA_FILE = Paths.get(
        System.getProperty("user.home"), ".smart-student-management", "students.csv"
    );

    public StudentManager() {
        loadStudents();
    }

    private void loadStudents() {
        if (!Files.exists(DATA_FILE)) return;
        try {
            for (String line : Files.readAllLines(DATA_FILE, StandardCharsets.UTF_8)) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length != 4) continue;
                long regno = Long.parseLong(parts[0]);
                String name = new String(Base64.getDecoder().decode(parts[1]), StandardCharsets.UTF_8);
                String course = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                double marks = Double.parseDouble(parts[3]);
                students.add(new Student(regno, name, course, marks));
            }
        } catch (IOException | IllegalArgumentException ex) {
            System.err.println("Could not load saved student data: " + ex.getMessage());
        }
    }

    private void saveStudents() {
        try {
            Files.createDirectories(DATA_FILE.getParent());
            List<String> lines = new ArrayList<>();
            for (Student student : students) {
                String name = Base64.getEncoder().encodeToString(student.getName().getBytes(StandardCharsets.UTF_8));
                String course = Base64.getEncoder().encodeToString(student.getCourse().getBytes(StandardCharsets.UTF_8));
                lines.add(student.getRegno() + "," + name + "," + course + "," + student.getMarks());
            }
            Files.write(DATA_FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.err.println("Could not save student data to " + DATA_FILE + ": " + ex.getMessage());
        }
    }

    // Read-only access for the GUI; callers cannot modify the internal list directly.
    public List<Student> getAllStudents() {
        return Collections.unmodifiableList(new ArrayList<>(students));
    }

    public Student findStudent(long regno) {
        for (Student student : students) {
            if (student.getRegno() == regno) {
                return student;
            }
        }
        return null;
    }

    public void addStudent(Student student) {

        for (Student existingStudent : students) {

            if (existingStudent.getRegno() == student.getRegno()) {
                System.out.println("Registration number already exists!");
                return;
            }
        }

        students.add(student);
        saveStudents();

        System.out.println(
            "Student " + student.getRegno() + " added successfully!"
        );
    }

    public void displayAllStudents() {

        if (students.isEmpty()){
            System.out.println("No Students Found.");
            return;
        }

        for (Student student : students) {
            student.DisplayStudent();
            System.out.println("----------------");
        }
    }

    public void searchStudent(long regno) {

        if (students.isEmpty()){
            System.out.println("No Students Found.");
            return;
        }

        Student student = findStudent(regno);
        if (student != null) {
            System.out.println("Student " + student.getRegno() + " Found.");
            student.DisplayStudent();
            return;
        }

        System.out.println("Student Not Found.");
    }

    public void updateMarks(long regno, double newMarks) {

        if (students.isEmpty()){
            System.out.println("No Students Found.");
            return;
        }

        Student student = findStudent(regno);
        if (student != null) {
            student.setMarks(newMarks);
            saveStudents();
            System.out.println(
                "Marks Updated To " + student.getMarks() + " Successfully!"
            );
            return;
        }

        System.out.println("Student Not Found.");
    }

    public void deleteStudent(long regno) {

        if (students.isEmpty()){
            System.out.println("No Students Found.");
            return;
        }

        Student student = findStudent(regno);
        if (student != null) {
            students.remove(student);
            saveStudents();
            System.out.println(
                "Student " + student.getRegno() + " Deleted Successfully!"
            );
            return;
        }

        System.out.println("Student Not Found.");
    }

    public void statisticStudent() {

        if (students.isEmpty()){
            System.out.println("No Students Found.");
            return;
        }

        double sum = 0;
        int totalCount = 0;
        int passCount = 0;

        for (Student student : students) {
            sum = sum + student.getMarks();
            totalCount++;
        }

        double mean = sum / totalCount;

        System.out.println("Total No. of Students is " + totalCount);
        System.out.println("Average Marks = " + mean);

        for (Student student : students) {
            if (student.getMarks() >= 40) {
                passCount++;
            }
        }

        double passRate = ((double) passCount / totalCount) * 100;
        System.out.println("The pass rate is " + passRate + "%");
    }
}
