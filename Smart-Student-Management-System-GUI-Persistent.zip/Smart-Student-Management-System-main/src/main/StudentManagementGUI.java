package main;

import model.Student;
import service.StudentManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** A desktop GUI for the existing Smart Student Management System backend. */
public class StudentManagementGUI extends JFrame {
    private static final Color NAVY = new Color(22, 32, 58);
    private static final Color BLUE = new Color(64, 104, 237);
    private static final Color BG = new Color(245, 247, 252);
    private static final Color TEXT = new Color(39, 49, 71);
    private static final Color MUTED = new Color(115, 125, 145);
    private static final Color BORDER = new Color(226, 231, 241);

    private final StudentManager manager = new StudentManager();
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Registration No.", "Student Name", "Course", "Marks", "Grade", "Status"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable studentTable = new JTable(tableModel);
    private final JTextField searchField = new JTextField(18);
    private final JLabel totalValue = new JLabel("0");
    private final JLabel averageValue = new JLabel("—");
    private final JLabel passRateValue = new JLabel("—");
    private final JLabel passCountValue = new JLabel("0");
    private final JLabel statusLabel = new JLabel("Ready");

    public StudentManagementGUI() {
        super("Smart Student Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1020, 680));
        setSize(1180, 760);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);
        refreshTable();
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(225, 0));
        sidebar.setBorder(new EmptyBorder(28, 18, 22, 18));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("SSMS");
        logo.setFont(new Font("SansSerif", Font.BOLD, 25));
        logo.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("STUDENT PORTAL");
        subtitle.setFont(new Font("SansSerif", Font.BOLD, 10));
        subtitle.setForeground(new Color(161, 178, 218));
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(42));
        sidebar.add(sidebarItem("▦", "Dashboard", true));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(sidebarItem("▤", "Student records", false));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(sidebarItem("▥", "Performance", false));
        sidebar.add(Box.createVerticalGlue());

        JPanel note = new JPanel();
        note.setOpaque(false);
        note.setLayout(new BoxLayout(note, BoxLayout.Y_AXIS));
        JLabel noteTitle = new JLabel("STUDENT MANAGEMENT");
        noteTitle.setForeground(new Color(165, 180, 216));
        noteTitle.setFont(new Font("SansSerif", Font.BOLD, 9));
        JLabel noteText = new JLabel("Simple. Smart. Organized.");
        noteText.setForeground(Color.WHITE);
        noteText.setFont(new Font("SansSerif", Font.PLAIN, 11));
        note.add(noteTitle);
        note.add(Box.createVerticalStrut(7));
        note.add(noteText);
        sidebar.add(note);
        return sidebar;
    }

    private JPanel sidebarItem(String icon, String label, boolean active) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        item.setMaximumSize(new Dimension(190, 44));
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        item.setBackground(active ? new Color(52, 68, 108) : NAVY);
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("SansSerif", Font.BOLD, 17));
        iconLabel.setForeground(active ? Color.WHITE : new Color(170, 184, 216));
        JLabel textLabel = new JLabel(label);
        textLabel.setFont(new Font("SansSerif", active ? Font.BOLD : Font.PLAIN, 13));
        textLabel.setForeground(active ? Color.WHITE : new Color(202, 211, 232));
        item.add(iconLabel);
        item.add(textLabel);
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        item.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (label.equals("Student records")) {
                    studentTable.requestFocusInWindow();
                    studentTable.scrollRectToVisible(new Rectangle(0, 0, 1, 1));
                } else if (label.equals("Performance")) {
                    showStatistics();
                } else {
                    searchField.setText("");
                    refreshTable();
                }
            }
        });
        return item;
    }

    private JPanel buildMainContent() {
        JPanel main = new JPanel(new BorderLayout(0, 22));
        main.setBackground(BG);
        main.setBorder(new EmptyBorder(28, 30, 18, 30));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        JLabel eyebrow = new JLabel("OVERVIEW  /  STUDENTS");
        eyebrow.setForeground(BLUE);
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 10));
        JLabel heading = new JLabel("Student dashboard");
        heading.setForeground(TEXT);
        heading.setFont(new Font("SansSerif", Font.BOLD, 27));
        JLabel description = new JLabel("Manage student details and track academic performance.");
        description.setForeground(MUTED);
        description.setFont(new Font("SansSerif", Font.PLAIN, 12));
        titles.add(eyebrow);
        titles.add(Box.createVerticalStrut(6));
        titles.add(heading);
        titles.add(Box.createVerticalStrut(5));
        titles.add(description);

        JButton addButton = primaryButton("+  Add student");
        addButton.addActionListener(e -> showAddStudentDialog());
        header.add(titles, BorderLayout.CENTER);
        header.add(addButton, BorderLayout.EAST);

        JPanel center = new JPanel(new BorderLayout(0, 20));
        center.setOpaque(false);
        center.add(buildStats(), BorderLayout.NORTH);
        center.add(buildRecordsPanel(), BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        statusLabel.setForeground(MUTED);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        JLabel footerRight = new JLabel("SMART STUDENT MANAGEMENT SYSTEM");
        footerRight.setForeground(new Color(151, 159, 177));
        footerRight.setFont(new Font("SansSerif", Font.BOLD, 9));
        footer.add(statusLabel, BorderLayout.WEST);
        footer.add(footerRight, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);
        main.add(center, BorderLayout.CENTER);
        main.add(footer, BorderLayout.SOUTH);
        return main;
    }

    private JPanel buildStats() {
        JPanel stats = new JPanel(new GridLayout(1, 4, 14, 0));
        stats.setOpaque(false);
        stats.add(statCard("TOTAL STUDENTS", totalValue, "Currently registered", new Color(64, 104, 237)));
        stats.add(statCard("AVERAGE MARKS", averageValue, "Out of 100", new Color(30, 157, 126)));
        stats.add(statCard("PASS RATE", passRateValue, "Marks of 40+", new Color(220, 151, 53)));
        stats.add(statCard("STUDENTS PASSED", passCountValue, "Meeting pass criteria", new Color(139, 92, 220)));
        return stats;
    }

    private JPanel statCard(String title, JLabel value, String caption, Color accent) {
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(16, 16, 14, 16)));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(MUTED);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 9));
        value.setForeground(TEXT);
        value.setFont(new Font("SansSerif", Font.BOLD, 27));
        JLabel captionLabel = new JLabel(caption);
        captionLabel.setForeground(MUTED);
        captionLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        JPanel marker = new JPanel();
        marker.setBackground(accent);
        marker.setPreferredSize(new Dimension(30, 3));
        marker.setMaximumSize(new Dimension(30, 3));
        marker.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(titleLabel);
        card.add(Box.createVerticalStrut(13));
        card.add(value);
        card.add(Box.createVerticalStrut(5));
        card.add(captionLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(marker);
        return card;
    }

    private JPanel buildRecordsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 14));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(18, 18, 16, 18)));

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);
        JPanel labels = new JPanel();
        labels.setOpaque(false);
        labels.setLayout(new BoxLayout(labels, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Student records");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 17));
        JLabel sub = new JLabel("View, search, edit marks, or remove a record.");
        sub.setForeground(MUTED);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 11));
        labels.add(title);
        labels.add(Box.createVerticalStrut(4));
        labels.add(sub);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        searchPanel.setOpaque(false);
        searchField.setPreferredSize(new Dimension(175, 34));
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        searchField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),
                new EmptyBorder(5, 9, 5, 9)));
        searchField.setToolTipText("Search by registration number, name, or course");
        JButton searchButton = secondaryButton("Search");
        searchButton.addActionListener(e -> filterTable());
        searchField.addActionListener(e -> filterTable());
        JButton clearButton = secondaryButton("Clear");
        clearButton.addActionListener(e -> { searchField.setText(""); refreshTable(); });
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearButton);
        top.add(labels, BorderLayout.WEST);
        top.add(searchPanel, BorderLayout.EAST);

        studentTable.setRowHeight(37);
        studentTable.setFont(new Font("SansSerif", Font.PLAIN, 12));
        studentTable.setForeground(TEXT);
        studentTable.setGridColor(new Color(237, 240, 246));
        studentTable.setShowVerticalLines(false);
        studentTable.setSelectionBackground(new Color(231, 237, 255));
        studentTable.setSelectionForeground(TEXT);
        studentTable.setFillsViewportHeight(true);
        studentTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 10));
        studentTable.getTableHeader().setForeground(MUTED);
        studentTable.getTableHeader().setBackground(new Color(248, 249, 252));
        studentTable.getTableHeader().setPreferredSize(new Dimension(0, 35));
        studentTable.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        studentTable.getColumnModel().getColumn(0).setPreferredWidth(115);
        studentTable.getColumnModel().getColumn(1).setPreferredWidth(170);
        studentTable.getColumnModel().getColumn(2).setPreferredWidth(130);
        JScrollPane scroll = new JScrollPane(studentTable);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));
        scroll.getViewport().setBackground(Color.WHITE);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        JButton updateButton = secondaryButton("Update marks");
        updateButton.addActionListener(e -> updateSelectedStudent());
        JButton deleteButton = dangerButton("Delete student");
        deleteButton.addActionListener(e -> deleteSelectedStudent());
        JButton statsButton = secondaryButton("View statistics");
        statsButton.addActionListener(e -> showStatistics());
        actions.add(updateButton);
        actions.add(deleteButton);
        actions.add(statsButton);

        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(BLUE);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(11, 16, 11, 16));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JButton secondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 11));
        button.setForeground(TEXT);
        button.setBackground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),
                new EmptyBorder(7, 10, 7, 10)));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JButton dangerButton(String text) {
        JButton button = secondaryButton(text);
        button.setForeground(new Color(190, 57, 70));
        return button;
    }

    private void showAddStudentDialog() {
        JTextField regField = new JTextField(18);
        JTextField nameField = new JTextField(18);
        JTextField courseField = new JTextField(18);
        JTextField marksField = new JTextField(18);
        JPanel form = formPanel(new String[]{"Registration number", "Student name", "Course", "Marks (0–100)"},
                new JComponent[]{regField, nameField, courseField, marksField});
        int result = JOptionPane.showConfirmDialog(this, form, "Add a student",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        try {
            long regno = Long.parseLong(regField.getText().trim());
            String name = nameField.getText().trim();
            String course = courseField.getText().trim();
            double marks = Double.parseDouble(marksField.getText().trim());
            if (regno <= 0) throw new IllegalArgumentException("Registration number must be positive.");
            if (name.isEmpty() || course.isEmpty()) throw new IllegalArgumentException("Name and course cannot be empty.");
            validateMarks(marks);
            if (manager.findStudent(regno) != null) {
                showError("That registration number already exists.");
                return;
            }
            manager.addStudent(new Student(regno, name, course, marks));
            refreshTable();
            statusLabel.setText("Added student: " + name);
            JOptionPane.showMessageDialog(this, "Student added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            showError("Enter a valid registration number and numeric marks.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private JPanel formPanel(String[] labels, JComponent[] fields) {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(8, 8, 4, 8));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(7, 6, 7, 6);
        c.fill = GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i; c.weightx = 0;
            JLabel label = new JLabel(labels[i]);
            label.setFont(new Font("SansSerif", Font.PLAIN, 12));
            form.add(label, c);
            c.gridx = 1; c.weightx = 1;
            fields[i].setPreferredSize(new Dimension(190, 30));
            form.add(fields[i], c);
        }
        return form;
    }

    private void updateSelectedStudent() {
        Student student = selectedStudent();
        if (student == null) return;
        String input = JOptionPane.showInputDialog(this,
                "Enter new marks for " + student.getName() + " (0–100):", student.getMarks());
        if (input == null) return;
        try {
            double marks = Double.parseDouble(input.trim());
            validateMarks(marks);
            manager.updateMarks(student.getRegno(), marks);
            refreshTable();
            statusLabel.setText("Updated marks for " + student.getName());
        } catch (NumberFormatException ex) {
            showError("Marks must be a number between 0 and 100.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void deleteSelectedStudent() {
        Student student = selectedStudent();
        if (student == null) return;
        int choice = JOptionPane.showConfirmDialog(this,
                "Delete " + student.getName() + " (Reg. No. " + student.getRegno() + ")?",
                "Confirm deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            manager.deleteStudent(student.getRegno());
            refreshTable();
            statusLabel.setText("Deleted student: " + student.getName());
        }
    }

    private Student selectedStudent() {
        int row = studentTable.getSelectedRow();
        if (row < 0) {
            showError("Select a student row first.");
            return null;
        }
        long regno = Long.parseLong(tableModel.getValueAt(studentTable.convertRowIndexToModel(row), 0).toString());
        return manager.findStudent(regno);
    }

    private void filterTable() {
        String query = searchField.getText().trim().toLowerCase();
        tableModel.setRowCount(0);
        for (Student student : manager.getAllStudents()) {
            if (query.isEmpty() || String.valueOf(student.getRegno()).contains(query)
                    || student.getName().toLowerCase().contains(query)
                    || student.getCourse().toLowerCase().contains(query)) {
                addStudentRow(student);
            }
        }
        statusLabel.setText(query.isEmpty() ? "Showing all student records" : "Search results for: " + searchField.getText().trim());
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Student student : manager.getAllStudents()) addStudentRow(student);
        updateStats();
    }

    private void addStudentRow(Student student) {
        String grade = student.CalcGrade(student.getMarks());
        String status = student.getMarks() >= 40 ? "Passed" : "Needs improvement";
        tableModel.addRow(new Object[]{student.getRegno(), student.getName(), student.getCourse(),
                String.format("%.1f", student.getMarks()), grade, status});
    }

    private void updateStats() {
        List<Student> students = manager.getAllStudents();
        int total = students.size();
        double sum = 0;
        int passed = 0;
        for (Student student : students) {
            sum += student.getMarks();
            if (student.getMarks() >= 40) passed++;
        }
        totalValue.setText(String.valueOf(total));
        averageValue.setText(total == 0 ? "—" : String.format("%.1f", sum / total));
        passRateValue.setText(total == 0 ? "—" : String.format("%.0f%%", passed * 100.0 / total));
        passCountValue.setText(String.valueOf(passed));
    }

    private void showStatistics() {
        List<Student> students = manager.getAllStudents();
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No student records yet. Add a student to see statistics.",
                    "Performance statistics", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        double sum = 0;
        int passed = 0;
        Student top = students.get(0);
        for (Student student : students) {
            sum += student.getMarks();
            if (student.getMarks() >= 40) passed++;
            if (student.getMarks() > top.getMarks()) top = student;
        }
        String message = String.format(
                "Total students: %d%nAverage marks: %.2f / 100%nPassed: %d%nFailed: %d%nPass rate: %.1f%%%nTop performer: %s (%.1f marks)",
                students.size(), sum / students.size(), passed, students.size() - passed,
                passed * 100.0 / students.size(), top.getName(), top.getMarks());
        JOptionPane.showMessageDialog(this, message, "Performance statistics", JOptionPane.INFORMATION_MESSAGE);
    }

    private void validateMarks(double marks) {
        if (marks < 0 || marks > 100 || Double.isNaN(marks) || Double.isInfinite(marks)) {
            throw new IllegalArgumentException("Marks must be between 0 and 100.");
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Please check", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> new StudentManagementGUI().setVisible(true));
    }
}
